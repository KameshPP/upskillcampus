# CivicFix — Urban Issue Management Platform

A full-stack civic complaint management system with role-based access for Citizens, Officers, and Field Workers. Includes AI-powered completion verification via Google Gemini.

---

## Tech Stack

- **Frontend:** React 18, Vite, React Router, Leaflet, Axios, React Hot Toast
- **Backend:** Spring Boot 3.2, Spring Security (JWT), Spring Data JPA
- **Database:** MySQL 8
- **AI:** Google Gemini 1.5 Flash API

---

## Project Structure

```
civicfix/
├── frontend/          (Vite + React)
│   └── src/
│       ├── pages/
│       │   ├── auth/        LoginPage, RegisterPage
│       │   ├── citizen/     Dashboard, Complaints, Map
│       │   ├── officer/     Dashboard, Complaints, Map, Users
│       │   └── worker/      Dashboard, Tasks
│       ├── components/
│       │   ├── common/      Sidebar, PageLayout, StatCard, Button
│       │   └── complaint/   ComplaintCard
│       ├── context/         StoreContext (global state)
│       └── api/             Axios API methods by role
└── backend/           (Spring Boot)
    └── src/main/java/com/civicfix/
        ├── model/           User, Complaint
        ├── repository/      UserRepository, ComplaintRepository
        ├── service/         UserService, ComplaintService, GeminiService
        ├── controller/      AuthController, ComplaintController
        ├── dto/             DTOs
        ├── security/        JwtUtil, JwtAuthFilter
        └── config/          SecurityConfig, WebConfig
```

---

## Prerequisites

- Java 17+
- Maven 3.8+
- Node.js 18+
- MySQL 8.0+

---

## Setup Instructions

### 1. MySQL Setup

```sql
CREATE DATABASE civicfix;
-- The application will auto-create tables on first run
```

### 2. Backend Setup

1. Navigate to `backend/`
2. Edit `src/main/resources/application.properties`:
   - Set `spring.datasource.username` and `spring.datasource.password`
3. Run:
```bash
mvn clean install
mvn spring-boot:run
```
Backend starts on `http://localhost:8080`

### 3. Frontend Setup

1. Navigate to `frontend/`
2. Install dependencies:
```bash
npm install
```
3. Start development server:
```bash
npm run dev
```
Frontend starts on `http://localhost:5173`

---

## User Roles

| Role     | Capabilities |
|----------|-------------|
| CITIZEN  | File complaints with GPS + photo, upvote nearby issues, track status |
| OFFICER  | View all complaints on map, assign workers, override AI verification |
| WORKER   | View assigned tasks, update status, submit completion photo for AI check |

---

## AI Verification Flow

1. **Citizen** files complaint → uploads **before photo**
2. **Officer** assigns a **worker** with ETA
3. **Worker** travels to location, does the work
4. **Worker** captures **current GPS** + uploads **after photo**
5. **Gemini AI** compares before/after photos + checks GPS distance (<100m)
6. If verified → auto-marked as **VERIFIED**
7. If AI fails or confidence low → **Officer manually reviews** and overrides

---

## API Endpoints

### Auth
- `POST /api/auth/register` — Register user
- `POST /api/auth/login` — Login, returns JWT

### Citizen
- `POST /api/citizen/complaints` — File complaint (multipart)
- `GET /api/citizen/complaints` — My complaints
- `POST /api/citizen/complaints/{id}/upvote` — Toggle upvote
- `GET /api/complaints/nearby?lat=&lng=&radius=` — Nearby complaints

### Officer
- `GET /api/officer/complaints` — All complaints
- `POST /api/officer/complaints/{id}/assign` — Assign worker
- `POST /api/officer/complaints/{id}/override?status=` — Manual override
- `GET /api/officer/workers` — List field workers
- `GET /api/officer/users` — All users

### Worker
- `GET /api/worker/complaints` — My assigned tasks
- `POST /api/worker/complaints/{id}/complete?lat=&lng=` — Submit completion
- `PATCH /api/worker/complaints/{id}/status?status=` — Update status

---

## Environment Configuration

Update `backend/src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/civicfix?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=YOUR_MYSQL_USERNAME
spring.datasource.password=YOUR_MYSQL_PASSWORD

app.gemini.api.key=AIzaSyDozEK2o7C0t_ewfmHHXmMLP-IP67l3tng
app.upload.dir=./uploads
app.cors.allowed-origins=http://localhost:5173
```
