package com.civicfix.service;

import com.civicfix.dto.DTOs;
import com.google.gson.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.util.Base64;

@Service
public class GeminiService {

    @Value("${app.gemini.api.key}")
    private String apiKey;

    @Value("${app.gemini.api.url}")
    private String apiUrl;

    public DTOs.AiVerificationResult verifyCompletion(
            String beforeImagePath,
            String afterImagePath,
            double beforeLat, double beforeLng,
            double afterLat, double afterLng,
            String complaintDescription) {

        DTOs.AiVerificationResult result = new DTOs.AiVerificationResult();

        try {
            // Check location match (within 100 meters)
            double distance = calculateDistance(beforeLat, beforeLng, afterLat, afterLng);
            boolean locationMatch = distance <= 0.1; // 100 meters in km
            result.setLocationMatch(locationMatch);

            // Build Gemini request
            String beforeBase64 = encodeImageToBase64(beforeImagePath);
            String afterBase64 = encodeImageToBase64(afterImagePath);

            String prompt = String.format(
                "You are a civic complaint verification AI. Compare these two images:\n" +
                "Image 1 (BEFORE): The original reported issue - '%s'\n" +
                "Image 2 (AFTER): The completion photo submitted by the worker.\n\n" +
                "Analyze:\n" +
                "1. Is the issue from Image 1 resolved in Image 2?\n" +
                "2. Do both images appear to show the same location?\n" +
                "3. Is the work quality acceptable?\n\n" +
                "Location GPS check: Distance between photos = %.0f meters. %s\n\n" +
                "Respond ONLY in JSON format:\n" +
                "{\"verified\": true/false, \"workCompleted\": true/false, \"reasoning\": \"...\", \"confidenceScore\": 0.0-1.0}",
                complaintDescription,
                distance * 1000,
                locationMatch ? "LOCATION MATCH OK" : "WARNING: LOCATION MISMATCH DETECTED"
            );

            JsonObject requestBody = buildGeminiRequest(prompt, beforeBase64, afterBase64);
            String responseStr = callGeminiApi(requestBody.toString());
            parseGeminiResponse(responseStr, result);
            result.setLocationMatch(locationMatch);

        } catch (Exception e) {
            result.setVerified(false);
            result.setReasoning("AI verification failed: " + e.getMessage());
            result.setConfidenceScore(0.0);
        }

        return result;
    }

    private JsonObject buildGeminiRequest(String prompt, String beforeBase64, String afterBase64) {
        JsonObject requestBody = new JsonObject();
        JsonArray contents = new JsonArray();
        JsonObject content = new JsonObject();
        JsonArray parts = new JsonArray();

        JsonObject textPart = new JsonObject();
        textPart.addProperty("text", prompt);
        parts.add(textPart);

        if (beforeBase64 != null) {
            JsonObject beforeImagePart = new JsonObject();
            JsonObject beforeInlineData = new JsonObject();
            beforeInlineData.addProperty("mimeType", "image/jpeg");
            beforeInlineData.addProperty("data", beforeBase64);
            beforeImagePart.add("inlineData", beforeInlineData);
            parts.add(beforeImagePart);
        }

        if (afterBase64 != null) {
            JsonObject afterImagePart = new JsonObject();
            JsonObject afterInlineData = new JsonObject();
            afterInlineData.addProperty("mimeType", "image/jpeg");
            afterInlineData.addProperty("data", afterBase64);
            afterImagePart.add("inlineData", afterInlineData);
            parts.add(afterImagePart);
        }

        content.add("parts", parts);
        contents.add(content);
        requestBody.add("contents", contents);

        JsonObject generationConfig = new JsonObject();
        generationConfig.addProperty("temperature", 0.1);
        requestBody.add("generationConfig", generationConfig);

        return requestBody;
    }

    private String callGeminiApi(String requestBodyStr) throws IOException {
        URL url = new URL(apiUrl + "?key=" + apiKey);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(requestBodyStr.getBytes());
        }

        StringBuilder response = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            String line;
            while ((line = br.readLine()) != null) {
                response.append(line);
            }
        }
        return response.toString();
    }

    private void parseGeminiResponse(String responseStr, DTOs.AiVerificationResult result) {
        try {
            JsonObject response = JsonParser.parseString(responseStr).getAsJsonObject();
            String text = response.getAsJsonArray("candidates")
                    .get(0).getAsJsonObject()
                    .getAsJsonObject("content")
                    .getAsJsonArray("parts")
                    .get(0).getAsJsonObject()
                    .get("text").getAsString();

            // Extract JSON from text
            int start = text.indexOf("{");
            int end = text.lastIndexOf("}") + 1;
            if (start >= 0 && end > start) {
                String jsonPart = text.substring(start, end);
                JsonObject parsed = JsonParser.parseString(jsonPart).getAsJsonObject();
                result.setVerified(parsed.has("verified") && parsed.get("verified").getAsBoolean());
                result.setWorkCompleted(parsed.has("workCompleted") && parsed.get("workCompleted").getAsBoolean());
                result.setReasoning(parsed.has("reasoning") ? parsed.get("reasoning").getAsString() : "No reasoning provided");
                result.setConfidenceScore(parsed.has("confidenceScore") ? parsed.get("confidenceScore").getAsDouble() : 0.5);
            }
        } catch (Exception e) {
            result.setVerified(false);
            result.setReasoning("Could not parse AI response");
            result.setConfidenceScore(0.0);
        }
    }

    private String encodeImageToBase64(String imagePath) {
        if (imagePath == null) return null;
        try {
            File file = new File(imagePath);
            if (!file.exists()) return null;
            byte[] bytes = Files.readAllBytes(file.toPath());
            return Base64.getEncoder().encodeToString(bytes);
        } catch (IOException e) {
            return null;
        }
    }

    private double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        final int R = 6371;
        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }
}
