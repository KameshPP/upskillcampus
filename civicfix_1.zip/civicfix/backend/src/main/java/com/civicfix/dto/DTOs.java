package com.civicfix.dto;

import com.civicfix.model.Complaint;
import com.civicfix.model.User;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.Set;

public class DTOs {

    @Data
    public static class LoginRequest {
        private String email;
        private String password;
    }

    @Data
    public static class RegisterRequest {
        private String email;
        private String password;
        private String fullName;
        private String phone;
        private User.Role role;
    }

    @Data
    public static class AuthResponse {
        private String token;
        private UserDTO user;
    }

    @Data
    public static class UserDTO {
        private Long id;
        private String email;
        private String fullName;
        private String phone;
        private User.Role role;
        private boolean active;
        private LocalDateTime createdAt;
    }

    @Data
    public static class ComplaintRequest {
        private String title;
        private String description;
        private Complaint.Category category;
        private Complaint.Priority priority;
        private Double latitude;
        private Double longitude;
        private String address;
    }

    @Data
    public static class ComplaintDTO {
        private Long id;
        private String title;
        private String description;
        private Complaint.Category category;
        private Complaint.Priority priority;
        private Complaint.Status status;
        private Double latitude;
        private Double longitude;
        private String address;
        private String beforePhotoUrl;
        private String afterPhotoUrl;
        private UserDTO citizen;
        private UserDTO assignedOfficer;
        private UserDTO assignedWorker;
        private int upvotes;
        private Set<Long> upvoterIds;
        private LocalDateTime estimatedCompletionTime;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
        private LocalDateTime completedAt;
        private String aiVerificationResult;
        private boolean aiVerified;
        private boolean officerOverride;
    }

    @Data
    public static class AssignRequest {
        private Long workerId;
        private LocalDateTime estimatedCompletionTime;
    }

    @Data
    public static class AiVerificationResult {
        private boolean verified;
        private String reasoning;
        private double confidenceScore;
        private boolean locationMatch;
        private boolean workCompleted;
    }
}
