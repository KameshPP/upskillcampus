package com.civicfix.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "complaints")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Complaint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    private Category category;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private Priority priority = Priority.MEDIUM;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private Status status = Status.PENDING;

    private Double latitude;
    private Double longitude;
    private String address;

    private String beforePhotoUrl;
    private String afterPhotoUrl;

    @ManyToOne
    @JoinColumn(name = "citizen_id", nullable = false)
    private User citizen;

    @ManyToOne
    @JoinColumn(name = "assigned_officer_id")
    private User assignedOfficer;

    @ManyToOne
    @JoinColumn(name = "assigned_worker_id")
    private User assignedWorker;

    @Builder.Default
    private int upvotes = 0;

    @ElementCollection
    @CollectionTable(name = "complaint_upvoters", joinColumns = @JoinColumn(name = "complaint_id"))
    @Column(name = "user_id")
    @Builder.Default
    private Set<Long> upvoterIds = new HashSet<>();

    private LocalDateTime estimatedCompletionTime;

    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    private LocalDateTime updatedAt;

    private LocalDateTime completedAt;

    private String aiVerificationResult;

    @Builder.Default
    private boolean aiVerified = false;

    @Builder.Default
    private boolean officerOverride = false;

    public enum Category {
        ROAD_DAMAGE, WATER_SUPPLY, ELECTRICITY, GARBAGE, SEWAGE, STREET_LIGHT, TREE, OTHER
    }

    public enum Priority {
        LOW, MEDIUM, HIGH, URGENT
    }

    public enum Status {
        PENDING, ASSIGNED, IN_PROGRESS, COMPLETED, VERIFIED, REJECTED, REOPENED
    }
}
