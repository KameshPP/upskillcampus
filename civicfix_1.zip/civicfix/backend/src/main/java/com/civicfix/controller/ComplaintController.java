package com.civicfix.controller;

import com.civicfix.dto.DTOs;
import com.civicfix.service.ComplaintService;
import com.civicfix.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.List;

@RestController
@RequestMapping("/api")
public class ComplaintController {

    @Autowired
    private ComplaintService complaintService;

    @Autowired
    private UserService userService;

    // CITIZEN endpoints
    @PostMapping("/citizen/complaints")
    public ResponseEntity<?> createComplaint(
            @RequestPart("data") String dataJson,
            @RequestPart(value = "photo", required = false) MultipartFile photo,
            Authentication auth) {
        try {
            com.google.gson.Gson gson = new com.google.gson.Gson();
            DTOs.ComplaintRequest request = gson.fromJson(dataJson, DTOs.ComplaintRequest.class);
            DTOs.ComplaintDTO dto = complaintService.createComplaint(request, photo, auth.getName());
            return ResponseEntity.ok(dto);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/citizen/complaints")
    public ResponseEntity<List<DTOs.ComplaintDTO>> getMyComplaints(Authentication auth) {
        return ResponseEntity.ok(complaintService.getComplaintsByUser(auth.getName()));
    }

    @PostMapping("/citizen/complaints/{id}/upvote")
    public ResponseEntity<?> upvote(@PathVariable Long id, Authentication auth) {
        try {
            return ResponseEntity.ok(complaintService.upvoteComplaint(id, auth.getName()));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/complaints/nearby")
    public ResponseEntity<List<DTOs.ComplaintDTO>> getNearby(
            @RequestParam double lat,
            @RequestParam double lng,
            @RequestParam(defaultValue = "5") double radius) {
        return ResponseEntity.ok(complaintService.getNearbyComplaints(lat, lng, radius));
    }

    @GetMapping("/complaints/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(complaintService.getComplaintById(id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // OFFICER endpoints
    @GetMapping("/officer/complaints")
    public ResponseEntity<List<DTOs.ComplaintDTO>> getAllComplaints() {
        return ResponseEntity.ok(complaintService.getAllComplaints());
    }

    @PostMapping("/officer/complaints/{id}/assign")
    public ResponseEntity<?> assignComplaint(
            @PathVariable Long id,
            @RequestBody DTOs.AssignRequest request,
            Authentication auth) {
        try {
            return ResponseEntity.ok(complaintService.assignComplaint(id, request, auth.getName()));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/officer/complaints/{id}/override")
    public ResponseEntity<?> officerOverride(
            @PathVariable Long id,
            @RequestParam String status,
            Authentication auth) {
        try {
            return ResponseEntity.ok(complaintService.officerOverride(id, status, auth.getName()));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/officer/workers")
    public ResponseEntity<?> getWorkers() {
        return ResponseEntity.ok(userService.getWorkers());
    }

    @GetMapping("/officer/users")
    public ResponseEntity<?> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    // WORKER endpoints
    @GetMapping("/worker/complaints")
    public ResponseEntity<List<DTOs.ComplaintDTO>> getWorkerComplaints(Authentication auth) {
        return ResponseEntity.ok(complaintService.getComplaintsByWorker(auth.getName()));
    }

    @PostMapping("/worker/complaints/{id}/complete")
    public ResponseEntity<?> submitCompletion(
            @PathVariable Long id,
            @RequestPart("photo") MultipartFile photo,
            @RequestParam double lat,
            @RequestParam double lng,
            Authentication auth) {
        try {
            return ResponseEntity.ok(complaintService.submitCompletion(id, photo, lat, lng, auth.getName()));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("/worker/complaints/{id}/status")
    public ResponseEntity<?> updateStatus(@PathVariable Long id, @RequestParam String status) {
        try {
            return ResponseEntity.ok(complaintService.updateStatus(id, status));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
