package com.civicfix.repository;

import com.civicfix.model.Complaint;
import com.civicfix.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ComplaintRepository extends JpaRepository<Complaint, Long> {
    List<Complaint> findByCitizen(User citizen);
    List<Complaint> findByAssignedWorker(User worker);
    List<Complaint> findByAssignedOfficer(User officer);
    List<Complaint> findByStatus(Complaint.Status status);

    @Query("SELECT c FROM Complaint c WHERE " +
           "(6371 * acos(cos(radians(:lat)) * cos(radians(c.latitude)) * " +
           "cos(radians(c.longitude) - radians(:lng)) + " +
           "sin(radians(:lat)) * sin(radians(c.latitude)))) < :radius")
    List<Complaint> findNearbyComplaints(
        @Param("lat") double lat,
        @Param("lng") double lng,
        @Param("radius") double radiusKm
    );

    List<Complaint> findAllByOrderByCreatedAtDesc();
    List<Complaint> findByStatusIn(List<Complaint.Status> statuses);
}
