package com.civicfix.service;

import com.civicfix.dto.DTOs;
import com.civicfix.model.Complaint;
import com.civicfix.model.User;
import com.civicfix.repository.ComplaintRepository;
import com.civicfix.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ComplaintService {

    @Autowired
    private ComplaintRepository complaintRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private GeminiService geminiService;

    @Value("${app.upload.dir}")
    private String uploadDir;

    public DTOs.ComplaintDTO createComplaint(DTOs.ComplaintRequest request, MultipartFile photo, String userEmail) {
        User citizen = userService.findByEmail(userEmail);

        Complaint complaint = Complaint.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .category(request.getCategory())
                .priority(request.getPriority())
                .latitude(request.getLatitude())
                .longitude(request.getLongitude())
                .address(request.getAddress())
                .citizen(citizen)
                .build();

        if (photo != null && !photo.isEmpty()) {
            String photoUrl = saveFile(photo, "before");
            complaint.setBeforePhotoUrl(photoUrl);
        }

        complaint = complaintRepository.save(complaint);
        return mapToDTO(complaint);
    }

    public List<DTOs.ComplaintDTO> getComplaintsByUser(String userEmail) {
        User user = userService.findByEmail(userEmail);
        return complaintRepository.findByCitizen(user).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public List<DTOs.ComplaintDTO> getNearbyComplaints(double lat, double lng, double radius) {
        return complaintRepository.findNearbyComplaints(lat, lng, radius).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public List<DTOs.ComplaintDTO> getAllComplaints() {
        return complaintRepository.findAllByOrderByCreatedAtDesc().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public DTOs.ComplaintDTO getComplaintById(Long id) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));
        return mapToDTO(complaint);
    }

    public DTOs.ComplaintDTO upvoteComplaint(Long complaintId, String userEmail) {
        User user = userService.findByEmail(userEmail);
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));

        if (complaint.getUpvoterIds().contains(user.getId())) {
            complaint.getUpvoterIds().remove(user.getId());
            complaint.setUpvotes(complaint.getUpvotes() - 1);
        } else {
            complaint.getUpvoterIds().add(user.getId());
            complaint.setUpvotes(complaint.getUpvotes() + 1);
        }

        complaint.setUpdatedAt(LocalDateTime.now());
        complaint = complaintRepository.save(complaint);
        return mapToDTO(complaint);
    }

    public DTOs.ComplaintDTO assignComplaint(Long complaintId, DTOs.AssignRequest request, String officerEmail) {
        User officer = userService.findByEmail(officerEmail);
        User worker = userRepository.findById(request.getWorkerId())
                .orElseThrow(() -> new RuntimeException("Worker not found"));

        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));

        complaint.setAssignedOfficer(officer);
        complaint.setAssignedWorker(worker);
        complaint.setStatus(Complaint.Status.ASSIGNED);
        complaint.setEstimatedCompletionTime(request.getEstimatedCompletionTime());
        complaint.setUpdatedAt(LocalDateTime.now());

        complaint = complaintRepository.save(complaint);
        return mapToDTO(complaint);
    }

    public DTOs.ComplaintDTO getWorkerComplaints(String workerEmail) {
        throw new RuntimeException("Use getComplaintsByWorker instead");
    }

    public List<DTOs.ComplaintDTO> getComplaintsByWorker(String workerEmail) {
        User worker = userService.findByEmail(workerEmail);
        return complaintRepository.findByAssignedWorker(worker).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public DTOs.ComplaintDTO submitCompletion(Long complaintId, MultipartFile photo, double lat, double lng, String workerEmail) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));

        String afterPhotoUrl = saveFile(photo, "after");
        complaint.setAfterPhotoUrl(afterPhotoUrl);
        complaint.setStatus(Complaint.Status.COMPLETED);
        complaint.setCompletedAt(LocalDateTime.now());
        complaint.setUpdatedAt(LocalDateTime.now());

        // Run AI verification
        try {
            String beforePath = uploadDir + "/" + complaint.getBeforePhotoUrl().replace("/uploads/", "");
            String afterPath = uploadDir + "/" + afterPhotoUrl.replace("/uploads/", "");

            DTOs.AiVerificationResult aiResult = geminiService.verifyCompletion(
                    beforePath, afterPath,
                    complaint.getLatitude(), complaint.getLongitude(),
                    lat, lng,
                    complaint.getDescription()
            );

            String resultJson = String.format(
                "{\"verified\":%b,\"workCompleted\":%b,\"reasoning\":\"%s\",\"confidenceScore\":%.2f,\"locationMatch\":%b}",
                aiResult.isVerified(), aiResult.isWorkCompleted(),
                aiResult.getReasoning().replace("\"", "'"),
                aiResult.getConfidenceScore(), aiResult.isLocationMatch()
            );
            complaint.setAiVerificationResult(resultJson);

            if (aiResult.isVerified() && aiResult.isLocationMatch()) {
                complaint.setAiVerified(true);
                complaint.setStatus(Complaint.Status.VERIFIED);
            }
        } catch (Exception e) {
            complaint.setAiVerificationResult("{\"error\":\"AI verification service unavailable\"}");
        }

        complaint = complaintRepository.save(complaint);
        return mapToDTO(complaint);
    }

    public DTOs.ComplaintDTO officerOverride(Long complaintId, String status, String officerEmail) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));

        complaint.setStatus(Complaint.Status.valueOf(status));
        complaint.setOfficerOverride(true);
        complaint.setUpdatedAt(LocalDateTime.now());
        complaint = complaintRepository.save(complaint);
        return mapToDTO(complaint);
    }

    public DTOs.ComplaintDTO updateStatus(Long complaintId, String status) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));
        complaint.setStatus(Complaint.Status.valueOf(status));
        complaint.setUpdatedAt(LocalDateTime.now());
        complaint = complaintRepository.save(complaint);
        return mapToDTO(complaint);
    }

    private String saveFile(MultipartFile file, String prefix) {
        try {
            File dir = new File(uploadDir);
            if (!dir.exists()) dir.mkdirs();
            String filename = prefix + "_" + UUID.randomUUID() + "_" + file.getOriginalFilename();
            Path path = Paths.get(uploadDir, filename);
            Files.write(path, file.getBytes());
            return "/uploads/" + filename;
        } catch (IOException e) {
            throw new RuntimeException("File upload failed: " + e.getMessage());
        }
    }

    public DTOs.ComplaintDTO mapToDTO(Complaint complaint) {
        DTOs.ComplaintDTO dto = new DTOs.ComplaintDTO();
        dto.setId(complaint.getId());
        dto.setTitle(complaint.getTitle());
        dto.setDescription(complaint.getDescription());
        dto.setCategory(complaint.getCategory());
        dto.setPriority(complaint.getPriority());
        dto.setStatus(complaint.getStatus());
        dto.setLatitude(complaint.getLatitude());
        dto.setLongitude(complaint.getLongitude());
        dto.setAddress(complaint.getAddress());
        dto.setBeforePhotoUrl(complaint.getBeforePhotoUrl());
        dto.setAfterPhotoUrl(complaint.getAfterPhotoUrl());
        dto.setCitizen(userService.mapToUserDTO(complaint.getCitizen()));
        if (complaint.getAssignedOfficer() != null)
            dto.setAssignedOfficer(userService.mapToUserDTO(complaint.getAssignedOfficer()));
        if (complaint.getAssignedWorker() != null)
            dto.setAssignedWorker(userService.mapToUserDTO(complaint.getAssignedWorker()));
        dto.setUpvotes(complaint.getUpvotes());
        dto.setUpvoterIds(complaint.getUpvoterIds());
        dto.setEstimatedCompletionTime(complaint.getEstimatedCompletionTime());
        dto.setCreatedAt(complaint.getCreatedAt());
        dto.setUpdatedAt(complaint.getUpdatedAt());
        dto.setCompletedAt(complaint.getCompletedAt());
        dto.setAiVerificationResult(complaint.getAiVerificationResult());
        dto.setAiVerified(complaint.isAiVerified());
        dto.setOfficerOverride(complaint.isOfficerOverride());
        return dto;
    }
}
