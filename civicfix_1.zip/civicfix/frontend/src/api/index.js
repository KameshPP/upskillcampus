import axios from 'axios'

const BASE_URL = '/api'

const api = axios.create({
  baseURL: BASE_URL,
})

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('civicfix_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('civicfix_token')
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

// Auth
export const authAPI = {
  login: (data) => api.post('/auth/login', data),
  register: (data) => api.post('/auth/register', data),
}

// Citizen
export const citizenAPI = {
  createComplaint: (formData) =>
    api.post('/citizen/complaints', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),
  getMyComplaints: () => api.get('/citizen/complaints'),
  upvote: (id) => api.post(`/citizen/complaints/${id}/upvote`),
  getNearby: (lat, lng, radius = 5) =>
    api.get(`/complaints/nearby?lat=${lat}&lng=${lng}&radius=${radius}`),
  getComplaintById: (id) => api.get(`/complaints/${id}`),
}

// Officer
export const officerAPI = {
  getAllComplaints: () => api.get('/officer/complaints'),
  assignComplaint: (id, data) => api.post(`/officer/complaints/${id}/assign`, data),
  override: (id, status) => api.post(`/officer/complaints/${id}/override?status=${status}`),
  getWorkers: () => api.get('/officer/workers'),
  getAllUsers: () => api.get('/officer/users'),
}

// Worker
export const workerAPI = {
  getMyComplaints: () => api.get('/worker/complaints'),
  submitCompletion: (id, formData, lat, lng) =>
    api.post(`/worker/complaints/${id}/complete?lat=${lat}&lng=${lng}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),
  updateStatus: (id, status) =>
    api.patch(`/worker/complaints/${id}/status?status=${status}`),
}

export default api
