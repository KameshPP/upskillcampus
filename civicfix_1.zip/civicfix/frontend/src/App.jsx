import React, { useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { StoreProvider, useStore } from './context/StoreContext'
import LoginPage from './pages/auth/LoginPage/LoginPage'
import RegisterPage from './pages/auth/RegisterPage/RegisterPage'
import CitizenDashboard from './pages/citizen/Dashboard/CitizenDashboard'
import CitizenComplaints from './pages/citizen/Complaints/CitizenComplaints'
import CitizenMap from './pages/citizen/Map/CitizenMap'
import OfficerDashboard from './pages/officer/Dashboard/OfficerDashboard'
import OfficerComplaints from './pages/officer/Complaints/OfficerComplaints'
import OfficerMap from './pages/officer/Map/OfficerMap'
import OfficerUsers from './pages/officer/Users/OfficerUsers'
import WorkerDashboard from './pages/worker/Dashboard/WorkerDashboard'
import WorkerTasks from './pages/worker/Tasks/WorkerTasks'

function ProtectedRoute({ children, roles }) {
  const { user, token } = useStore()
  if (!token) return <Navigate to="/login" replace />
  if (roles && user && !roles.includes(user.role)) {
    return <Navigate to="/login" replace />
  }
  return children
}

function RoleRedirect() {
  const { user, token } = useStore()
  if (!token) return <Navigate to="/login" replace />
  if (!user) return null
  if (user.role === 'CITIZEN') return <Navigate to="/citizen/dashboard" replace />
  if (user.role === 'OFFICER') return <Navigate to="/officer/dashboard" replace />
  if (user.role === 'WORKER') return <Navigate to="/worker/dashboard" replace />
  return <Navigate to="/login" replace />
}

function AppRoutes() {
  const { user, token, dispatch } = useStore()

  useEffect(() => {
    if (token && !user) {
      const stored = localStorage.getItem('civicfix_user')
      if (stored) {
        dispatch({ type: 'SET_USER', payload: JSON.parse(stored) })
      }
    }
  }, [token, user])

  return (
    <Routes>
      <Route path="/" element={<RoleRedirect />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />

      {/* Citizen */}
      <Route path="/citizen/dashboard" element={
        <ProtectedRoute roles={['CITIZEN']}><CitizenDashboard /></ProtectedRoute>
      } />
      <Route path="/citizen/complaints" element={
        <ProtectedRoute roles={['CITIZEN']}><CitizenComplaints /></ProtectedRoute>
      } />
      <Route path="/citizen/map" element={
        <ProtectedRoute roles={['CITIZEN']}><CitizenMap /></ProtectedRoute>
      } />

      {/* Officer */}
      <Route path="/officer/dashboard" element={
        <ProtectedRoute roles={['OFFICER']}><OfficerDashboard /></ProtectedRoute>
      } />
      <Route path="/officer/complaints" element={
        <ProtectedRoute roles={['OFFICER']}><OfficerComplaints /></ProtectedRoute>
      } />
      <Route path="/officer/map" element={
        <ProtectedRoute roles={['OFFICER']}><OfficerMap /></ProtectedRoute>
      } />
      <Route path="/officer/users" element={
        <ProtectedRoute roles={['OFFICER']}><OfficerUsers /></ProtectedRoute>
      } />

      {/* Worker */}
      <Route path="/worker/dashboard" element={
        <ProtectedRoute roles={['WORKER']}><WorkerDashboard /></ProtectedRoute>
      } />
      <Route path="/worker/tasks" element={
        <ProtectedRoute roles={['WORKER']}><WorkerTasks /></ProtectedRoute>
      } />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <StoreProvider>
      <BrowserRouter>
        <AppRoutes />
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#161d2e',
              color: '#e8f0fe',
              border: '1px solid #1e2d45',
              fontFamily: 'Sora, sans-serif',
              fontSize: '14px',
            },
          }}
        />
      </BrowserRouter>
    </StoreProvider>
  )
}
