import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import PageLayout from '../../../components/common/PageLayout/PageLayout'
import StatCard from '../../../components/common/StatCard/StatCard'
import { useStore } from '../../../context/StoreContext'
import { citizenAPI } from '../../../api'
import toast from 'react-hot-toast'
import './CitizenDashboard.css'

export default function CitizenDashboard() {
  const { user, complaints, dispatch } = useStore()
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    citizenAPI.getMyComplaints()
      .then(res => dispatch({ type: 'SET_COMPLAINTS', payload: res.data }))
      .catch(() => toast.error('Failed to load complaints'))
      .finally(() => setLoading(false))
  }, [])

  const stats = {
    total: complaints.length,
    pending: complaints.filter(c => c.status === 'PENDING').length,
    inProgress: complaints.filter(c => ['ASSIGNED', 'IN_PROGRESS'].includes(c.status)).length,
    resolved: complaints.filter(c => ['COMPLETED', 'VERIFIED'].includes(c.status)).length,
  }

  const recent = [...complaints].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5)

  const statusColor = {
    PENDING: '#ffab00', ASSIGNED: '#00d4ff', IN_PROGRESS: '#7c4dff',
    COMPLETED: '#00e676', VERIFIED: '#00e676', REJECTED: '#ff3d57',
  }

  return (
    <PageLayout
      title={`Welcome, ${user?.fullName?.split(' ')[0]}`}
      subtitle="Here is the status of your civic reports"
      actions={
        <button className="new-complaint-btn" onClick={() => navigate('/citizen/complaints')}>
          + New Complaint
        </button>
      }
    >
      <div className="stats-grid">
        <StatCard label="Total Reports" value={stats.total} icon="📋" color="var(--accent-primary)" />
        <StatCard label="Pending" value={stats.pending} icon="⏳" color="var(--accent-warning)" />
        <StatCard label="In Progress" value={stats.inProgress} icon="🔧" color="var(--accent-purple)" />
        <StatCard label="Resolved" value={stats.resolved} icon="✅" color="var(--accent-success)" />
      </div>

      <div className="dash-section">
        <div className="section-header">
          <h2 className="section-title">Recent Reports</h2>
          <button className="section-link" onClick={() => navigate('/citizen/complaints')}>View All</button>
        </div>

        {loading ? (
          <div className="loading-list">{[1,2,3].map(i => <div key={i} className="skeleton-row" />)}</div>
        ) : recent.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📋</div>
            <p>No complaints filed yet.</p>
            <button className="new-complaint-btn" onClick={() => navigate('/citizen/complaints')}>File your first complaint</button>
          </div>
        ) : (
          <div className="recent-list">
            {recent.map(c => (
              <div key={c.id} className="recent-item" onClick={() => navigate('/citizen/complaints')}>
                <div className="recent-left">
                  <div className="recent-title">{c.title}</div>
                  <div className="recent-meta">{c.address || 'No address'} · {new Date(c.createdAt).toLocaleDateString()}</div>
                </div>
                <div className="recent-right">
                  <span className="status-pill" style={{ color: statusColor[c.status], borderColor: statusColor[c.status] + '40', background: statusColor[c.status] + '15' }}>
                    {c.status.replace('_', ' ')}
                  </span>
                  <span className="upvote-tag">▲ {c.upvotes}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="dash-section">
        <div className="section-header">
          <h2 className="section-title">Quick Actions</h2>
        </div>
        <div className="quick-actions">
          <div className="qa-card" onClick={() => navigate('/citizen/complaints')}>
            <div className="qa-icon">◈</div>
            <div className="qa-label">File Complaint</div>
            <div className="qa-desc">Report a new civic issue in your area</div>
          </div>
          <div className="qa-card" onClick={() => navigate('/citizen/map')}>
            <div className="qa-icon">◎</div>
            <div className="qa-label">Nearby Issues</div>
            <div className="qa-desc">See complaints around you on the map</div>
          </div>
          <div className="qa-card" onClick={() => navigate('/citizen/complaints')}>
            <div className="qa-icon">▲</div>
            <div className="qa-label">Upvote Issues</div>
            <div className="qa-desc">Support complaints that affect you too</div>
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
