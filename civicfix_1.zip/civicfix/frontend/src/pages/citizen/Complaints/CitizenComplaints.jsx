import React, { useEffect, useState, useRef } from 'react'
import PageLayout from '../../../components/common/PageLayout/PageLayout'
import ComplaintCard from '../../../components/complaint/ComplaintCard/ComplaintCard'
import { useStore } from '../../../context/StoreContext'
import { citizenAPI } from '../../../api'
import toast from 'react-hot-toast'
import './CitizenComplaints.css'

const categories = ['ROAD_DAMAGE','WATER_SUPPLY','ELECTRICITY','GARBAGE','SEWAGE','STREET_LIGHT','TREE','OTHER']
const priorities = ['LOW','MEDIUM','HIGH','URGENT']

export default function CitizenComplaints() {
  const { user, complaints, dispatch } = useStore()
  const [showModal, setShowModal] = useState(false)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [locating, setLocating] = useState(false)
  const [filter, setFilter] = useState('ALL')
  const [form, setForm] = useState({
    title: '', description: '', category: 'ROAD_DAMAGE', priority: 'MEDIUM',
    latitude: null, longitude: null, address: ''
  })
  const [photo, setPhoto] = useState(null)
  const [photoPreview, setPhotoPreview] = useState(null)
  const fileRef = useRef()

  useEffect(() => {
    citizenAPI.getMyComplaints()
      .then(res => dispatch({ type: 'SET_COMPLAINTS', payload: res.data }))
      .catch(() => toast.error('Failed to load complaints'))
      .finally(() => setLoading(false))
  }, [])

  const getLocation = () => {
    setLocating(true)
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords
        setForm(f => ({ ...f, latitude, longitude }))
        try {
          const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`)
          const data = await res.json()
          setForm(f => ({ ...f, address: data.display_name?.slice(0, 100) || `${latitude.toFixed(4)}, ${longitude.toFixed(4)}` }))
        } catch {
          setForm(f => ({ ...f, address: `${latitude.toFixed(4)}, ${longitude.toFixed(4)}` }))
        }
        toast.success('Location captured')
        setLocating(false)
      },
      (err) => {
        toast.error('Location access denied')
        setLocating(false)
      }
    )
  }

  const handlePhotoChange = (e) => {
    const file = e.target.files[0]
    if (!file) return
    setPhoto(file)
    setPhotoPreview(URL.createObjectURL(file))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.title || !form.description) { toast.error('Fill required fields'); return }
    if (!form.latitude) { toast.error('Please capture your location'); return }

    setSubmitting(true)
    try {
      const fd = new FormData()
      fd.append('data', JSON.stringify(form))
      if (photo) fd.append('photo', photo)
      const res = await citizenAPI.createComplaint(fd)
      dispatch({ type: 'ADD_COMPLAINT', payload: res.data })
      toast.success('Complaint filed successfully')
      setShowModal(false)
      setForm({ title: '', description: '', category: 'ROAD_DAMAGE', priority: 'MEDIUM', latitude: null, longitude: null, address: '' })
      setPhoto(null); setPhotoPreview(null)
    } catch (err) {
      toast.error(err.response?.data || 'Failed to submit complaint')
    } finally {
      setSubmitting(false)
    }
  }

  const handleUpvote = async (id) => {
    try {
      const res = await citizenAPI.upvote(id)
      dispatch({ type: 'UPDATE_COMPLAINT', payload: res.data })
    } catch { toast.error('Upvote failed') }
  }

  const filtered = filter === 'ALL' ? complaints : complaints.filter(c => c.status === filter)

  return (
    <PageLayout
      title="My Complaints"
      subtitle={`${complaints.length} total reports filed`}
      actions={
        <button className="new-complaint-btn" onClick={() => setShowModal(true)}>+ File Complaint</button>
      }
    >
      <div className="filter-bar">
        {['ALL','PENDING','ASSIGNED','IN_PROGRESS','COMPLETED','VERIFIED'].map(s => (
          <button key={s} className={`filter-btn ${filter === s ? 'active' : ''}`} onClick={() => setFilter(s)}>
            {s.replace('_', ' ')}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="loading-list">{[1,2,3].map(i => <div key={i} className="skeleton-card" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📋</div>
          <p>{filter === 'ALL' ? 'No complaints filed yet.' : `No complaints with status "${filter}".`}</p>
          {filter === 'ALL' && <button className="new-complaint-btn" onClick={() => setShowModal(true)}>File your first complaint</button>}
        </div>
      ) : (
        <div className="complaints-grid">
          {filtered.map(c => (
            <ComplaintCard
              key={c.id}
              complaint={c}
              currentUserId={user?.id}
              actions={
                <button className="upvote-btn" onClick={() => handleUpvote(c.id)}>
                  ▲ {c.upvotes}
                </button>
              }
            />
          ))}
        </div>
      )}

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>File New Complaint</h2>
              <button className="modal-close" onClick={() => setShowModal(false)}>✕</button>
            </div>
            <form onSubmit={handleSubmit} className="modal-form">
              <div className="form-row">
                <div className="form-group">
                  <label>Title *</label>
                  <input className="form-input" value={form.title} onChange={e => setForm({...form, title: e.target.value})} placeholder="Brief description of the issue" />
                </div>
              </div>
              <div className="form-row two-col">
                <div className="form-group">
                  <label>Category</label>
                  <select className="form-input form-select" value={form.category} onChange={e => setForm({...form, category: e.target.value})}>
                    {categories.map(c => <option key={c} value={c}>{c.replace('_', ' ')}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Priority</label>
                  <select className="form-input form-select" value={form.priority} onChange={e => setForm({...form, priority: e.target.value})}>
                    {priorities.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label>Description *</label>
                <textarea className="form-input form-textarea" value={form.description} onChange={e => setForm({...form, description: e.target.value})} placeholder="Describe the issue in detail..." rows={3} />
              </div>
              <div className="form-group">
                <label>Location</label>
                <div className="location-row">
                  <input className="form-input" value={form.address} onChange={e => setForm({...form, address: e.target.value})} placeholder="Auto-detected or enter manually" />
                  <button type="button" className="locate-btn" onClick={getLocation} disabled={locating}>
                    {locating ? '...' : '◎ Detect'}
                  </button>
                </div>
                {form.latitude && (
                  <div className="coords-tag">
                    ✓ GPS: {form.latitude.toFixed(5)}, {form.longitude.toFixed(5)}
                  </div>
                )}
              </div>
              <div className="form-group">
                <label>Photo (Before)</label>
                <div className="photo-upload" onClick={() => fileRef.current.click()}>
                  {photoPreview ? (
                    <img src={photoPreview} alt="preview" className="photo-preview" />
                  ) : (
                    <div className="photo-placeholder">
                      <span>📷</span>
                      <span>Click to upload photo</span>
                    </div>
                  )}
                </div>
                <input ref={fileRef} type="file" accept="image/*" onChange={handlePhotoChange} hidden />
              </div>
              <div className="modal-footer">
                <button type="button" className="btn-cancel" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="new-complaint-btn" disabled={submitting}>
                  {submitting ? 'Submitting...' : 'Submit Complaint'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </PageLayout>
  )
}
