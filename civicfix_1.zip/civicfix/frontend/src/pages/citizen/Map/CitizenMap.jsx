import React, { useEffect, useState } from 'react'
import { MapContainer, TileLayer, Marker, Popup, Circle } from 'react-leaflet'
import L from 'leaflet'
import PageLayout from '../../../components/common/PageLayout/PageLayout'
import { useStore } from '../../../context/StoreContext'
import { citizenAPI } from '../../../api'
import toast from 'react-hot-toast'
import './CitizenMap.css'

const priorityColors = { URGENT: '#ff3d57', HIGH: '#ffab00', MEDIUM: '#00d4ff', LOW: '#00e676' }

function createIcon(color) {
  return L.divIcon({
    className: '',
    html: `<div style="width:14px;height:14px;background:${color};border:2px solid #fff;border-radius:50%;box-shadow:0 0 8px ${color}80"></div>`,
    iconSize: [14, 14],
    iconAnchor: [7, 7],
  })
}

export default function CitizenMap() {
  const { nearbyComplaints, dispatch, user } = useStore()
  const [userPos, setUserPos] = useState(null)
  const [radius, setRadius] = useState(5)
  const [loading, setLoading] = useState(false)
  const [selected, setSelected] = useState(null)
  const [upvoting, setUpvoting] = useState(false)

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      pos => {
        const { latitude, longitude } = pos.coords
        setUserPos([latitude, longitude])
        fetchNearby(latitude, longitude, radius)
      },
      () => toast.error('Location access required to show nearby complaints')
    )
  }, [])

  const fetchNearby = (lat, lng, r) => {
    setLoading(true)
    citizenAPI.getNearby(lat, lng, r)
      .then(res => dispatch({ type: 'SET_NEARBY_COMPLAINTS', payload: res.data }))
      .catch(() => toast.error('Failed to load nearby complaints'))
      .finally(() => setLoading(false))
  }

  const handleRadiusChange = (r) => {
    setRadius(r)
    if (userPos) fetchNearby(userPos[0], userPos[1], r)
  }

  const handleUpvote = async (id) => {
    setUpvoting(true)
    try {
      const res = await citizenAPI.upvote(id)
      dispatch({ type: 'UPDATE_COMPLAINT', payload: res.data })
      setSelected(res.data)
    } catch { toast.error('Upvote failed') }
    finally { setUpvoting(false) }
  }

  const statusColor = { PENDING: '#ffab00', ASSIGNED: '#00d4ff', IN_PROGRESS: '#7c4dff', COMPLETED: '#00e676', VERIFIED: '#00e676' }

  return (
    <PageLayout title="Nearby Issues" subtitle="Complaints in your area on the map">
      <div className="map-page">
        <div className="map-controls">
          <div className="radius-control">
            <label>Search Radius</label>
            <div className="radius-btns">
              {[1, 2, 5, 10].map(r => (
                <button key={r} className={`radius-btn ${radius === r ? 'active' : ''}`} onClick={() => handleRadiusChange(r)}>
                  {r} km
                </button>
              ))}
            </div>
          </div>
          <div className="map-legend">
            {Object.entries(priorityColors).map(([p, c]) => (
              <div key={p} className="legend-item">
                <div className="legend-dot" style={{ background: c }} />
                <span>{p}</span>
              </div>
            ))}
          </div>
          <div className="nearby-count">
            {loading ? 'Loading...' : `${nearbyComplaints.length} complaints found`}
          </div>
        </div>

        <div className="map-content">
          <div className="map-wrap">
            {userPos ? (
              <MapContainer center={userPos} zoom={13} className="leaflet-map">
                <TileLayer
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='&copy; OpenStreetMap contributors'
                />
                <Marker position={userPos} icon={L.divIcon({
                  className: '',
                  html: `<div style="width:16px;height:16px;background:#00d4ff;border:3px solid #fff;border-radius:50%;box-shadow:0 0 12px #00d4ff"></div>`,
                  iconSize: [16, 16], iconAnchor: [8, 8],
                })}>
                  <Popup>Your Location</Popup>
                </Marker>
                <Circle center={userPos} radius={radius * 1000} pathOptions={{ color: '#00d4ff', fillColor: '#00d4ff', fillOpacity: 0.04, weight: 1 }} />
                {nearbyComplaints.map(c => c.latitude && c.longitude && (
                  <Marker
                    key={c.id}
                    position={[c.latitude, c.longitude]}
                    icon={createIcon(priorityColors[c.priority] || '#00d4ff')}
                    eventHandlers={{ click: () => setSelected(c) }}
                  >
                    <Popup>
                      <div className="map-popup">
                        <div className="popup-title">{c.title}</div>
                        <div className="popup-meta">{c.category?.replace('_',' ')} · {c.status}</div>
                      </div>
                    </Popup>
                  </Marker>
                ))}
              </MapContainer>
            ) : (
              <div className="map-loading">Waiting for your location...</div>
            )}
          </div>

          <div className="map-sidebar">
            {selected ? (
              <div className="complaint-detail">
                <button className="back-btn" onClick={() => setSelected(null)}>← Back</button>
                <div className="detail-header">
                  <h3>{selected.title}</h3>
                  <span className="detail-status" style={{ color: statusColor[selected.status] }}>
                    {selected.status?.replace('_',' ')}
                  </span>
                </div>
                <p className="detail-desc">{selected.description}</p>
                {selected.beforePhotoUrl && (
                  <img src={selected.beforePhotoUrl} alt="Issue" className="detail-photo" />
                )}
                <div className="detail-meta-list">
                  <div className="detail-meta-row"><span>Category</span><span>{selected.category?.replace('_',' ')}</span></div>
                  <div className="detail-meta-row"><span>Priority</span><span style={{ color: priorityColors[selected.priority] }}>{selected.priority}</span></div>
                  <div className="detail-meta-row"><span>Filed by</span><span>{selected.citizen?.fullName}</span></div>
                  {selected.assignedWorker && (
                    <div className="detail-meta-row"><span>Worker</span><span>{selected.assignedWorker.fullName}</span></div>
                  )}
                  {selected.estimatedCompletionTime && (
                    <div className="detail-meta-row"><span>ETA</span><span>{new Date(selected.estimatedCompletionTime).toLocaleDateString()}</span></div>
                  )}
                </div>
                {selected.aiVerified && (
                  <div className="ai-verified-badge">AI Verified ✓</div>
                )}
                <button className="upvote-large-btn" onClick={() => handleUpvote(selected.id)} disabled={upvoting}>
                  ▲ Upvote ({selected.upvotes})
                </button>
              </div>
            ) : (
              <div className="nearby-list">
                <h3 className="nearby-title">Nearby Complaints</h3>
                {nearbyComplaints.length === 0 ? (
                  <p className="no-nearby">No complaints in this area.</p>
                ) : (
                  nearbyComplaints.map(c => (
                    <div key={c.id} className="nearby-item" onClick={() => setSelected(c)}>
                      <div className="nearby-dot" style={{ background: priorityColors[c.priority] }} />
                      <div>
                        <div className="nearby-item-title">{c.title}</div>
                        <div className="nearby-item-meta">▲ {c.upvotes} · {c.status?.replace('_',' ')}</div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
