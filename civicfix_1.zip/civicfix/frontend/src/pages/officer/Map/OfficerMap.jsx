import React, { useEffect, useState } from 'react'
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet'
import L from 'leaflet'
import PageLayout from '../../../components/common/PageLayout/PageLayout'
import { useStore } from '../../../context/StoreContext'
import { officerAPI } from '../../../api'
import toast from 'react-hot-toast'
import './OfficerMap.css'

const statusColors = {
  PENDING: '#ffab00', ASSIGNED: '#00d4ff', IN_PROGRESS: '#7c4dff',
  COMPLETED: '#00e676', VERIFIED: '#00e676', REJECTED: '#ff3d57',
}

function makeIcon(color) {
  return L.divIcon({
    className: '',
    html: `<div style="width:16px;height:16px;background:${color};border:2px solid #fff;border-radius:50%;box-shadow:0 0 10px ${color}80"></div>`,
    iconSize: [16, 16],
    iconAnchor: [8, 8],
  })
}

export default function OfficerMap() {
  const { complaints, dispatch } = useStore()
  const [loading, setLoading] = useState(true)
  const [filterStatus, setFilterStatus] = useState('ALL')

  useEffect(() => {
    officerAPI.getAllComplaints()
      .then(res => dispatch({ type: 'SET_COMPLAINTS', payload: res.data }))
      .catch(() => toast.error('Failed to load complaints'))
      .finally(() => setLoading(false))
  }, [])

  const filtered = filterStatus === 'ALL'
    ? complaints
    : complaints.filter(c => c.status === filterStatus)

  const withCoords = filtered.filter(c => c.latitude && c.longitude)
  const center = withCoords.length > 0
    ? [withCoords[0].latitude, withCoords[0].longitude]
    : [20.5937, 78.9629] // India center default

  return (
    <PageLayout title="Complaints Map" subtitle="Geographic view of all complaints">
      <div className="officer-map-page">
        <div className="map-top-controls">
          <div className="filter-bar">
            {['ALL','PENDING','ASSIGNED','IN_PROGRESS','COMPLETED','VERIFIED'].map(s => (
              <button key={s} className={`filter-btn ${filterStatus === s ? 'active' : ''}`} onClick={() => setFilterStatus(s)}>
                {s.replace('_',' ')}
              </button>
            ))}
          </div>
          <div className="map-legend">
            {Object.entries(statusColors).map(([s, c]) => (
              <div key={s} className="legend-item">
                <div className="legend-dot" style={{ background: c }} />
                <span>{s.replace('_',' ')}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="officer-map-wrap">
          {loading ? (
            <div className="map-loading">Loading complaints...</div>
          ) : (
            <MapContainer center={center} zoom={11} className="leaflet-map-full">
              <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution='&copy; OpenStreetMap contributors' />
              {withCoords.map(c => (
                <Marker key={c.id} position={[c.latitude, c.longitude]} icon={makeIcon(statusColors[c.status] || '#888')}>
                  <Popup>
                    <div style={{ fontFamily: 'Sora, sans-serif', minWidth: '200px' }}>
                      <div style={{ fontWeight: 700, fontSize: '13px', marginBottom: '4px' }}>{c.title}</div>
                      <div style={{ fontSize: '11px', color: '#666', marginBottom: '4px' }}>{c.category?.replace('_',' ')} · ▲ {c.upvotes}</div>
                      <div style={{ fontSize: '11px', fontWeight: 600, color: statusColors[c.status] }}>{c.status?.replace('_',' ')}</div>
                      {c.assignedWorker && <div style={{ fontSize: '11px', color: '#888', marginTop: '4px' }}>Worker: {c.assignedWorker.fullName}</div>}
                    </div>
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          )}
        </div>

        <div className="map-stats-bar">
          <div className="map-stat"><span className="ms-val">{complaints.length}</span><span className="ms-label">Total</span></div>
          <div className="map-stat"><span className="ms-val" style={{ color: '#ffab00' }}>{complaints.filter(c => c.status === 'PENDING').length}</span><span className="ms-label">Pending</span></div>
          <div className="map-stat"><span className="ms-val" style={{ color: '#7c4dff' }}>{complaints.filter(c => c.status === 'IN_PROGRESS').length}</span><span className="ms-label">In Progress</span></div>
          <div className="map-stat"><span className="ms-val" style={{ color: '#00e676' }}>{complaints.filter(c => c.status === 'VERIFIED').length}</span><span className="ms-label">Verified</span></div>
          <div className="map-stat"><span className="ms-val" style={{ color: '#ff3d57' }}>{complaints.filter(c => c.priority === 'URGENT').length}</span><span className="ms-label">Urgent</span></div>
        </div>
      </div>
    </PageLayout>
  )
}
