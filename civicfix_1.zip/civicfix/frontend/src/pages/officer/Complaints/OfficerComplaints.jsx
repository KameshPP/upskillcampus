import React, { useEffect, useState } from 'react'
import PageLayout from '../../../components/common/PageLayout/PageLayout'
import ComplaintCard from '../../../components/complaint/ComplaintCard/ComplaintCard'
import { useStore } from '../../../context/StoreContext'
import { officerAPI } from '../../../api'
import toast from 'react-hot-toast'
import './OfficerComplaints.css'

export default function OfficerComplaints() {
  const { complaints, workers, dispatch } = useStore()
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('ALL')
  const [selected, setSelected] = useState(null)
  const [assignModal, setAssignModal] = useState(false)
  const [assignForm, setAssignForm] = useState({ workerId: '', estimatedCompletionTime: '' })
  const [submitting, setSubmitting] = useState(false)
  const [overriding, setOverriding] = useState(false)

  useEffect(() => {
    Promise.all([officerAPI.getAllComplaints(), officerAPI.getWorkers()])
      .then(([cRes, wRes]) => {
        dispatch({ type: 'SET_COMPLAINTS', payload: cRes.data })
        dispatch({ type: 'SET_WORKERS', payload: wRes.data })
      })
      .catch(() => toast.error('Failed to load data'))
      .finally(() => setLoading(false))
  }, [])

  const filtered = filter === 'ALL' ? complaints : complaints.filter(c =>
    filter === 'UNASSIGNED' ? c.status === 'PENDING' : c.status === filter
  )

  const handleAssign = async () => {
    if (!assignForm.workerId) { toast.error('Select a worker'); return }
    setSubmitting(true)
    try {
      const res = await officerAPI.assignComplaint(selected.id, {
        workerId: parseInt(assignForm.workerId),
        estimatedCompletionTime: assignForm.estimatedCompletionTime || null,
      })
      dispatch({ type: 'UPDATE_COMPLAINT', payload: res.data })
      setAssignModal(false)
      setSelected(res.data)
      toast.success('Worker assigned successfully')
    } catch (err) {
      toast.error(err.response?.data || 'Assignment failed')
    } finally {
      setSubmitting(false)
    }
  }

  const handleOverride = async (status) => {
    setOverriding(true)
    try {
      const res = await officerAPI.override(selected.id, status)
      dispatch({ type: 'UPDATE_COMPLAINT', payload: res.data })
      setSelected(res.data)
      toast.success(`Complaint marked as ${status}`)
    } catch (err) {
      toast.error('Override failed')
    } finally {
      setOverriding(false)
    }
  }

  const aiResult = selected?.aiVerificationResult ? (() => {
    try { return JSON.parse(selected.aiVerificationResult) } catch { return null }
  })() : null

  const statusColor = { PENDING: '#ffab00', ASSIGNED: '#00d4ff', IN_PROGRESS: '#7c4dff', COMPLETED: '#00e676', VERIFIED: '#00e676', REJECTED: '#ff3d57' }

  return (
    <PageLayout title="Complaint Management" subtitle={`${complaints.length} total complaints`}>
      <div className="oc-layout">
        <div className="oc-list">
          <div className="filter-bar">
            {['ALL','UNASSIGNED','ASSIGNED','IN_PROGRESS','COMPLETED','VERIFIED','REJECTED'].map(s => (
              <button key={s} className={`filter-btn ${filter === s ? 'active' : ''}`} onClick={() => setFilter(s)}>
                {s.replace('_', ' ')}
              </button>
            ))}
          </div>

          {loading ? (
            <div className="loading-list">{[1,2,3].map(i => <div key={i} className="skeleton-card" />)}</div>
          ) : filtered.length === 0 ? (
            <div className="empty-state"><div className="empty-icon">📋</div><p>No complaints found.</p></div>
          ) : (
            <div className="complaints-list">
              {filtered.map(c => (
                <ComplaintCard
                  key={c.id}
                  complaint={c}
                  onClick={() => setSelected(c)}
                />
              ))}
            </div>
          )}
        </div>

        {selected && (
          <div className="oc-detail">
            <div className="detail-top">
              <button className="back-btn" onClick={() => setSelected(null)}>✕ Close</button>
              <h2 className="detail-title">{selected.title}</h2>
              <span className="detail-status-pill" style={{ color: statusColor[selected.status], borderColor: statusColor[selected.status] + '40', background: statusColor[selected.status] + '15' }}>
                {selected.status?.replace('_',' ')}
              </span>
            </div>

            <p className="detail-desc">{selected.description}</p>

            {selected.beforePhotoUrl && (
              <div className="photo-compare">
                <div className="photo-box">
                  <div className="photo-label">Before</div>
                  <img src={selected.beforePhotoUrl} alt="Before" />
                </div>
                {selected.afterPhotoUrl && (
                  <div className="photo-box">
                    <div className="photo-label">After</div>
                    <img src={selected.afterPhotoUrl} alt="After" />
                  </div>
                )}
              </div>
            )}

            <div className="detail-info-grid">
              <div className="info-item"><span>Category</span><span>{selected.category?.replace('_',' ')}</span></div>
              <div className="info-item"><span>Priority</span><span>{selected.priority}</span></div>
              <div className="info-item"><span>Upvotes</span><span>▲ {selected.upvotes}</span></div>
              <div className="info-item"><span>Citizen</span><span>{selected.citizen?.fullName}</span></div>
              <div className="info-item"><span>Location</span><span>{selected.address || `${selected.latitude?.toFixed(4)}, ${selected.longitude?.toFixed(4)}`}</span></div>
              {selected.assignedWorker && <div className="info-item"><span>Worker</span><span>{selected.assignedWorker.fullName}</span></div>}
              {selected.estimatedCompletionTime && <div className="info-item"><span>ETA</span><span>{new Date(selected.estimatedCompletionTime).toLocaleDateString()}</span></div>}
            </div>

            {aiResult && (
              <div className={`ai-result-card ${aiResult.verified ? 'ai-pass' : 'ai-fail'}`}>
                <div className="ai-result-header">
                  <span>AI Verification</span>
                  <span className="ai-confidence">{Math.round((aiResult.confidenceScore || 0) * 100)}% confidence</span>
                </div>
                <div className="ai-checks">
                  <div className={`ai-check ${aiResult.workCompleted ? 'pass' : 'fail'}`}>
                    {aiResult.workCompleted ? '✓' : '✗'} Work Completed
                  </div>
                  <div className={`ai-check ${aiResult.locationMatch ? 'pass' : 'fail'}`}>
                    {aiResult.locationMatch ? '✓' : '✗'} Location Match
                  </div>
                  <div className={`ai-check ${aiResult.verified ? 'pass' : 'fail'}`}>
                    {aiResult.verified ? '✓' : '✗'} Overall Verified
                  </div>
                </div>
                <p className="ai-reasoning">{aiResult.reasoning}</p>
              </div>
            )}

            <div className="detail-actions">
              {selected.status === 'PENDING' && (
                <button className="action-btn assign-btn" onClick={() => setAssignModal(true)}>Assign Worker</button>
              )}
              {selected.status === 'COMPLETED' && !selected.aiVerified && (
                <>
                  <button className="action-btn verify-btn" onClick={() => handleOverride('VERIFIED')} disabled={overriding}>
                    {overriding ? '...' : 'Mark Verified'}
                  </button>
                  <button className="action-btn reject-btn" onClick={() => handleOverride('REJECTED')} disabled={overriding}>
                    {overriding ? '...' : 'Reject'}
                  </button>
                  <button className="action-btn reopen-btn" onClick={() => handleOverride('REOPENED')} disabled={overriding}>
                    Reopen
                  </button>
                </>
              )}
              {selected.status === 'REJECTED' && (
                <button className="action-btn reopen-btn" onClick={() => handleOverride('PENDING')} disabled={overriding}>
                  Reopen as Pending
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {assignModal && (
        <div className="modal-overlay" onClick={() => setAssignModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Assign Worker</h2>
              <button className="modal-close" onClick={() => setAssignModal(false)}>✕</button>
            </div>
            <div className="modal-form">
              <div className="form-group">
                <label>Select Worker</label>
                <select className="form-input form-select" value={assignForm.workerId} onChange={e => setAssignForm({...assignForm, workerId: e.target.value})}>
                  <option value="">Choose a field worker...</option>
                  {workers.map(w => (
                    <option key={w.id} value={w.id}>{w.fullName} — {w.email}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label>Estimated Completion</label>
                <input type="datetime-local" className="form-input" value={assignForm.estimatedCompletionTime} onChange={e => setAssignForm({...assignForm, estimatedCompletionTime: e.target.value})} />
              </div>
              <div className="modal-footer">
                <button className="btn-cancel" onClick={() => setAssignModal(false)}>Cancel</button>
                <button className="action-btn assign-btn" onClick={handleAssign} disabled={submitting}>
                  {submitting ? 'Assigning...' : 'Confirm Assignment'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </PageLayout>
  )
}
