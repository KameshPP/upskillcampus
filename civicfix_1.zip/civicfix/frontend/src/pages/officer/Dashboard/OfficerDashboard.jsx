import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import PageLayout from '../../../components/common/PageLayout/PageLayout'
import StatCard from '../../../components/common/StatCard/StatCard'
import { useStore } from '../../../context/StoreContext'
import { officerAPI } from '../../../api'
import toast from 'react-hot-toast'
import './OfficerDashboard.css'

export default function OfficerDashboard() {
  const { complaints, dispatch } = useStore()
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    Promise.all([
      officerAPI.getAllComplaints(),
      officerAPI.getWorkers(),
    ]).then(([cRes, wRes]) => {
      dispatch({ type: 'SET_COMPLAINTS', payload: cRes.data })
      dispatch({ type: 'SET_WORKERS', payload: wRes.data })
    }).catch(() => toast.error('Failed to load data'))
    .finally(() => setLoading(false))
  }, [])

  const stats = {
    total: complaints.length,
    pending: complaints.filter(c => c.status === 'PENDING').length,
    active: complaints.filter(c => ['ASSIGNED','IN_PROGRESS'].includes(c.status)).length,
    completed: complaints.filter(c => ['COMPLETED','VERIFIED'].includes(c.status)).length,
    urgent: complaints.filter(c => c.priority === 'URGENT').length,
  }

  const urgentList = complaints.filter(c => c.priority === 'URGENT' && c.status === 'PENDING').slice(0, 5)
  const recentCompleted = complaints.filter(c => c.status === 'COMPLETED' && !c.aiVerified).slice(0, 5)

  const catBreakdown = complaints.reduce((acc, c) => {
    acc[c.category] = (acc[c.category] || 0) + 1
    return acc
  }, {})

  return (
    <PageLayout title="Officer Dashboard" subtitle="Overview of all civic complaints">
      <div className="stats-grid five-col">
        <StatCard label="Total" value={stats.total} icon="📋" color="var(--accent-primary)" />
        <StatCard label="Pending" value={stats.pending} icon="⏳" color="var(--accent-warning)" />
        <StatCard label="Active" value={stats.active} icon="🔧" color="var(--accent-purple)" />
        <StatCard label="Resolved" value={stats.completed} icon="✅" color="var(--accent-success)" />
        <StatCard label="Urgent" value={stats.urgent} icon="🚨" color="var(--accent-danger)" />
      </div>

      <div className="officer-grid">
        <div className="officer-panel">
          <div className="section-header">
            <h2 className="section-title">Urgent Pending</h2>
            <button className="section-link" onClick={() => navigate('/officer/complaints')}>Manage All</button>
          </div>
          {urgentList.length === 0 ? (
            <div className="panel-empty">No urgent pending complaints</div>
          ) : (
            urgentList.map(c => (
              <div key={c.id} className="officer-list-item urgent-item">
                <div className="oli-left">
                  <div className="oli-title">{c.title}</div>
                  <div className="oli-meta">{c.address || 'No address'} · ▲ {c.upvotes}</div>
                </div>
                <button className="assign-quick-btn" onClick={() => navigate('/officer/complaints')}>Assign</button>
              </div>
            ))
          )}
        </div>

        <div className="officer-panel">
          <div className="section-header">
            <h2 className="section-title">Awaiting AI Verification</h2>
            <button className="section-link" onClick={() => navigate('/officer/complaints')}>View All</button>
          </div>
          {recentCompleted.length === 0 ? (
            <div className="panel-empty">No pending verifications</div>
          ) : (
            recentCompleted.map(c => (
              <div key={c.id} className="officer-list-item">
                <div className="oli-left">
                  <div className="oli-title">{c.title}</div>
                  <div className="oli-meta">Worker: {c.assignedWorker?.fullName || 'Unknown'}</div>
                </div>
                <button className="review-btn" onClick={() => navigate('/officer/complaints')}>Review</button>
              </div>
            ))
          )}
        </div>

        <div className="officer-panel">
          <div className="section-header">
            <h2 className="section-title">Category Breakdown</h2>
          </div>
          <div className="cat-breakdown">
            {Object.entries(catBreakdown).map(([cat, count]) => (
              <div key={cat} className="cat-row">
                <span className="cat-name">{cat.replace('_',' ')}</span>
                <div className="cat-bar-wrap">
                  <div className="cat-bar" style={{ width: `${(count / stats.total) * 100}%` }} />
                </div>
                <span className="cat-count">{count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
