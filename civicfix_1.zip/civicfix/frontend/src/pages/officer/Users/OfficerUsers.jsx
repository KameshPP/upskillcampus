import React, { useEffect, useState } from 'react'
import PageLayout from '../../../components/common/PageLayout/PageLayout'
import { officerAPI } from '../../../api'
import toast from 'react-hot-toast'
import './OfficerUsers.css'

const roleColors = { CITIZEN: '#00d4ff', OFFICER: '#7c4dff', WORKER: '#00e676' }

export default function OfficerUsers() {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('ALL')
  const [search, setSearch] = useState('')

  useEffect(() => {
    officerAPI.getAllUsers()
      .then(res => setUsers(res.data))
      .catch(() => toast.error('Failed to load users'))
      .finally(() => setLoading(false))
  }, [])

  const filtered = users.filter(u => {
    const roleMatch = filter === 'ALL' || u.role === filter
    const searchMatch = !search || u.fullName.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase())
    return roleMatch && searchMatch
  })

  const stats = {
    total: users.length,
    citizens: users.filter(u => u.role === 'CITIZEN').length,
    officers: users.filter(u => u.role === 'OFFICER').length,
    workers: users.filter(u => u.role === 'WORKER').length,
  }

  return (
    <PageLayout title="User Management" subtitle={`${users.length} registered users`}>
      <div className="users-stats">
        <div className="user-stat-card"><div className="usc-val">{stats.total}</div><div className="usc-label">Total Users</div></div>
        <div className="user-stat-card"><div className="usc-val" style={{ color: '#00d4ff' }}>{stats.citizens}</div><div className="usc-label">Citizens</div></div>
        <div className="user-stat-card"><div className="usc-val" style={{ color: '#7c4dff' }}>{stats.officers}</div><div className="usc-label">Officers</div></div>
        <div className="user-stat-card"><div className="usc-val" style={{ color: '#00e676' }}>{stats.workers}</div><div className="usc-label">Field Workers</div></div>
      </div>

      <div className="users-controls">
        <input
          type="text"
          placeholder="Search by name or email..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="search-input"
        />
        <div className="filter-bar">
          {['ALL','CITIZEN','OFFICER','WORKER'].map(r => (
            <button key={r} className={`filter-btn ${filter === r ? 'active' : ''}`} onClick={() => setFilter(r)}>{r}</button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="loading-list">{[1,2,3,4,5].map(i => <div key={i} className="skeleton-row" />)}</div>
      ) : (
        <div className="users-table">
          <div className="table-header">
            <div>Name</div>
            <div>Email</div>
            <div>Phone</div>
            <div>Role</div>
            <div>Joined</div>
            <div>Status</div>
          </div>
          {filtered.map(u => (
            <div key={u.id} className="table-row">
              <div className="user-name-cell">
                <div className="user-avatar-sm" style={{ borderColor: roleColors[u.role] }}>
                  {u.fullName.charAt(0).toUpperCase()}
                </div>
                <span>{u.fullName}</span>
              </div>
              <div className="cell-email">{u.email}</div>
              <div className="cell-phone">{u.phone || '—'}</div>
              <div>
                <span className="role-badge" style={{ color: roleColors[u.role], background: roleColors[u.role] + '18', borderColor: roleColors[u.role] + '40' }}>
                  {u.role}
                </span>
              </div>
              <div className="cell-date">{u.createdAt ? new Date(u.createdAt).toLocaleDateString() : '—'}</div>
              <div>
                <span className={`status-dot-badge ${u.active ? 'active' : 'inactive'}`}>
                  {u.active ? 'Active' : 'Inactive'}
                </span>
              </div>
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="table-empty">No users found.</div>
          )}
        </div>
      )}
    </PageLayout>
  )
}
