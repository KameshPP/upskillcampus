import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useStore } from '../../../context/StoreContext'
import { authAPI } from '../../../api'
import toast from 'react-hot-toast'
import './RegisterPage.css'

const roles = [
  { value: 'CITIZEN', label: 'Citizen', emoji: '🏙', desc: 'Report issues' },
  { value: 'OFFICER', label: 'Officer', emoji: '🏛', desc: 'Manage complaints' },
  { value: 'WORKER', label: 'Field Worker', emoji: '🔧', desc: 'Resolve issues' },
]

export default function RegisterPage() {
  const [form, setForm] = useState({ fullName: '', email: '', password: '', phone: '', role: 'CITIZEN' })
  const [loading, setLoading] = useState(false)
  const { login } = useStore()
  const navigate = useNavigate()

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.fullName || !form.email || !form.password) {
      toast.error('Please fill required fields')
      return
    }
    setLoading(true)
    try {
      const res = await authAPI.register(form)
      const { token, user } = res.data
      login(user, token)
      localStorage.setItem('civicfix_user', JSON.stringify(user))
      toast.success('Account created!')
      if (user.role === 'CITIZEN') navigate('/citizen/dashboard')
      else if (user.role === 'OFFICER') navigate('/officer/dashboard')
      else navigate('/worker/dashboard')
    } catch (err) {
      toast.error(err.response?.data || 'Registration failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-left">
        <div className="auth-brand">
          <div className="auth-logo-mark">C</div>
          <div className="auth-brand-text">CivicFix</div>
        </div>
        <div className="auth-hero">
          <h1>Join the<br />civic network.</h1>
          <p>Choose your role and start making a difference in your community today.</p>
        </div>
        <div className="auth-features">
          <div className="feature-item"><span>🏙</span> Citizens report local issues</div>
          <div className="feature-item"><span>🏛</span> Officers manage and assign work</div>
          <div className="feature-item"><span>🔧</span> Field workers resolve problems</div>
        </div>
      </div>

      <div className="auth-right">
        <div className="auth-card">
          <h2 className="auth-title">Create Account</h2>
          <p className="auth-subtitle">Join CivicFix to get started</p>

          <form onSubmit={handleSubmit} className="auth-form">
            <div className="form-group">
              <label>Role</label>
              <div className="auth-role-grid">
                {roles.map((r) => (
                  <div
                    key={r.value}
                    className={`role-option ${form.role === r.value ? 'selected' : ''}`}
                    onClick={() => setForm({ ...form, role: r.value })}
                  >
                    <span className="role-emoji">{r.emoji}</span>
                    <span>{r.label}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="form-group">
              <label>Full Name</label>
              <input
                type="text"
                name="fullName"
                value={form.fullName}
                onChange={handleChange}
                placeholder="Your full name"
                className="form-input"
              />
            </div>
            <div className="form-group">
              <label>Email Address</label>
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                placeholder="you@example.com"
                className="form-input"
              />
            </div>
            <div className="form-group">
              <label>Phone (optional)</label>
              <input
                type="tel"
                name="phone"
                value={form.phone}
                onChange={handleChange}
                placeholder="+1 234 567 8900"
                className="form-input"
              />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                name="password"
                value={form.password}
                onChange={handleChange}
                placeholder="Create a strong password"
                className="form-input"
              />
            </div>
            <button type="submit" className="auth-btn" disabled={loading}>
              {loading ? <span className="auth-spinner" /> : 'Create Account'}
            </button>
          </form>

          <p className="auth-switch">
            Already have an account? <Link to="/login">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
