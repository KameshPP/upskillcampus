import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useStore } from '../../../context/StoreContext'
import { authAPI } from '../../../api'
import toast from 'react-hot-toast'
import './LoginPage.css'

export default function LoginPage() {
  const [form, setForm] = useState({ email: '', password: '' })
  const [loading, setLoading] = useState(false)
  const { login } = useStore()
  const navigate = useNavigate()

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.email || !form.password) {
      toast.error('Please fill in all fields')
      return
    }
    setLoading(true)
    try {
      const res = await authAPI.login(form)
      const { token, user } = res.data
      login(user, token)
      localStorage.setItem('civicfix_user', JSON.stringify(user))
      toast.success(`Welcome back, ${user.fullName}`)
      if (user.role === 'CITIZEN') navigate('/citizen/dashboard')
      else if (user.role === 'OFFICER') navigate('/officer/dashboard')
      else navigate('/worker/dashboard')
    } catch (err) {
      toast.error(err.response?.data || 'Login failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-left">
        <div className="auth-brand">
          <div className="auth-logo-mark">C</div>
          <div className="auth-brand-text">CivicFix</div>
        </div>
        <div className="auth-hero">
          <h1>Urban issues,<br />resolved faster.</h1>
          <p>A unified platform connecting citizens, officers, and field workers to fix civic problems efficiently.</p>
        </div>
        <div className="auth-features">
          <div className="feature-item"><span>◎</span> Geolocation-based complaint filing</div>
          <div className="feature-item"><span>▲</span> Community upvoting system</div>
          <div className="feature-item"><span>◈</span> AI-powered completion verification</div>
          <div className="feature-item"><span>⬡</span> Real-time status tracking</div>
        </div>
      </div>

      <div className="auth-right">
        <div className="auth-card">
          <h2 className="auth-title">Sign In</h2>
          <p className="auth-subtitle">Access your CivicFix account</p>

          <form onSubmit={handleSubmit} className="auth-form">
            <div className="form-group">
              <label>Email Address</label>
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                placeholder="you@example.com"
                className="form-input"
                autoComplete="email"
              />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                name="password"
                value={form.password}
                onChange={handleChange}
                placeholder="Enter your password"
                className="form-input"
                autoComplete="current-password"
              />
            </div>
            <button type="submit" className="auth-btn" disabled={loading}>
              {loading ? <span className="auth-spinner" /> : 'Sign In'}
            </button>
          </form>

          <p className="auth-switch">
            No account? <Link to="/register">Create one</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
