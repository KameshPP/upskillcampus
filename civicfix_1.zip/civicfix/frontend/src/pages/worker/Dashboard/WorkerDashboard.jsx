import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import PageLayout from '../../../components/common/PageLayout/PageLayout'
import StatCard from '../../../components/common/StatCard/StatCard'
import { useStore } from '../../../context/StoreContext'
import { workerAPI } from '../../../api'
import toast from 'react-hot-toast'
import './WorkerDashboard.css'

export default function WorkerDashboard() {
  const { user, complaints, dispatch } = useStore()
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    workerAPI.getMyComplaints()
      .then(res => dispatch({ type: 'SET_COMPLAINTS', payload: res.data }))
      .catch(() => toast.error('Failed to load tasks'))
      .finally(() => setLoading(false))
  }, [])

  const stats = {
    assigned: complaints.filter(c => c.status === 'ASSIGNED').length,
    inProgress: complaints.filter(c => c.status === 'IN_PROGRESS').length,
    completed: complaints.filter(c => ['COMPLETED','VERIFIED'].includes(c.status)).length,
    total: complaints.length,
  }

  const urgent = complaints.filter(c => c.priority === 'URGENT' && ['ASSIGNED','IN_PROGRESS'].includes(c.status))
  const recent = [...complaints].sort((a,b) => new Date(b.updatedAt||b.createdAt) - new Date(a.updatedAt||a.createdAt)).slice(0, 5)

  const priorityColor = { URGENT: '#ff3d57', HIGH: '#ffab00', MEDIUM: '#00d4ff', LOW: '#00e676' }
  const statusColor = { ASSIGNED: '#00d4ff', IN_PROGRESS: '#7c4dff', COMPLETED: '#00e676', VERIFIED: '#00e676' }

  return (
    <PageLayout
      title={`Worker Portal`}
      subtitle={`Hello, ${user?.fullName} — here are your assigned tasks`}
      actions={
        <button className="new-complaint-btn" onClick={() => navigate('/worker/tasks')}>View All Tasks</button>
      }
    >
      <div className="stats-grid">
        <StatCard label="Assigned" value={stats.assigned} icon="📋" color="var(--accent-primary)" />
        <StatCard label="In Progress" value={stats.inProgress} icon="🔧" color="var(--accent-purple)" />
        <StatCard label="Completed" value={stats.completed} icon="✅" color="var(--accent-success)" />
        <StatCard label="Total Tasks" value={stats.total} icon="📊" color="var(--accent-warning)" />
      </div>

      {urgent.length > 0 && (
        <div className="urgent-alert">
          <div className="urgent-alert-icon">🚨</div>
          <div>
            <div className="urgent-alert-title">You have {urgent.length} urgent task{urgent.length > 1 ? 's' : ''}</div>
            <div className="urgent-alert-desc">These require immediate attention.</div>
          </div>
          <button className="new-complaint-btn" onClick={() => navigate('/worker/tasks')}>Go to Tasks</button>
        </div>
      )}

      <div className="worker-grid">
        <div className="worker-panel">
          <div className="section-header">
            <h2 className="section-title">Recent Activity</h2>
            <button className="section-link" onClick={() => navigate('/worker/tasks')}>All Tasks</button>
          </div>
          {loading ? (
            <div className="loading-list">{[1,2,3].map(i => <div key={i} className="skeleton-row" />)}</div>
          ) : recent.length === 0 ? (
            <div className="panel-empty">No tasks assigned yet.</div>
          ) : (
            recent.map(c => (
              <div key={c.id} className="worker-task-item" onClick={() => navigate('/worker/tasks')}>
                <div className="wti-priority" style={{ background: priorityColor[c.priority] + '20', borderColor: priorityColor[c.priority] + '40' }}>
                  <div className="priority-dot" style={{ background: priorityColor[c.priority] }} />
                  <span style={{ color: priorityColor[c.priority], fontSize: '10px', fontWeight: 700 }}>{c.priority}</span>
                </div>
                <div className="wti-info">
                  <div className="wti-title">{c.title}</div>
                  <div className="wti-meta">{c.address || 'No address'}</div>
                </div>
                <span className="wti-status" style={{ color: statusColor[c.status] }}>
                  {c.status?.replace('_',' ')}
                </span>
              </div>
            ))
          )}
        </div>

        <div className="worker-panel">
          <div className="section-header">
            <h2 className="section-title">How to Complete a Task</h2>
          </div>
          <div className="how-to-steps">
            <div className="step-item">
              <div className="step-num">1</div>
              <div>
                <div className="step-title">Go to your assigned task</div>
                <div className="step-desc">Find it in the Tasks section</div>
              </div>
            </div>
            <div className="step-item">
              <div className="step-num">2</div>
              <div>
                <div className="step-title">Navigate to the location</div>
                <div className="step-desc">Use the GPS coordinates provided</div>
              </div>
            </div>
            <div className="step-item">
              <div className="step-num">3</div>
              <div>
                <div className="step-title">Complete the work</div>
                <div className="step-desc">Fix the reported issue on-site</div>
              </div>
            </div>
            <div className="step-item">
              <div className="step-num">4</div>
              <div>
                <div className="step-title">Upload completion photo</div>
                <div className="step-desc">AI verifies your work automatically</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
