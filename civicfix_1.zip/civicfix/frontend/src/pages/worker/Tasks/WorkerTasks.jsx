import React, { useEffect, useState, useRef } from 'react'
import PageLayout from '../../../components/common/PageLayout/PageLayout'
import { useStore } from '../../../context/StoreContext'
import { workerAPI } from '../../../api'
import toast from 'react-hot-toast'
import './WorkerTasks.css'

const priorityColor = { URGENT: '#ff3d57', HIGH: '#ffab00', MEDIUM: '#00d4ff', LOW: '#00e676' }
const statusColor = { ASSIGNED: '#00d4ff', IN_PROGRESS: '#7c4dff', COMPLETED: '#00e676', VERIFIED: '#00e676', REJECTED: '#ff3d57' }

export default function WorkerTasks() {
  const { complaints, dispatch } = useStore()
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState(null)
  const [filter, setFilter] = useState('ALL')
  const [completing, setCompleting] = useState(false)
  const [completionPhoto, setCompletionPhoto] = useState(null)
  const [completionPreview, setCompletionPreview] = useState(null)
  const [gettingLocation, setGettingLocation] = useState(false)
  const [workerLocation, setWorkerLocation] = useState(null)
  const fileRef = useRef()

  useEffect(() => {
    workerAPI.getMyComplaints()
      .then(res => dispatch({ type: 'SET_COMPLAINTS', payload: res.data }))
      .catch(() => toast.error('Failed to load tasks'))
      .finally(() => setLoading(false))
  }, [])

  const filtered = filter === 'ALL' ? complaints : complaints.filter(c => c.status === filter)

  const handleStartWork = async (complaint) => {
    try {
      const res = await workerAPI.updateStatus(complaint.id, 'IN_PROGRESS')
      dispatch({ type: 'UPDATE_COMPLAINT', payload: res.data })
      setSelected(res.data)
      toast.success('Status updated to In Progress')
    } catch { toast.error('Failed to update status') }
  }

  const captureWorkerLocation = () => {
    setGettingLocation(true)
    navigator.geolocation.getCurrentPosition(
      pos => {
        setWorkerLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude })
        toast.success('Location captured for verification')
        setGettingLocation(false)
      },
      () => { toast.error('Location access required'); setGettingLocation(false) }
    )
  }

  const handlePhotoChange = (e) => {
    const file = e.target.files[0]
    if (!file) return
    setCompletionPhoto(file)
    setCompletionPreview(URL.createObjectURL(file))
  }

  const handleSubmitCompletion = async () => {
    if (!completionPhoto) { toast.error('Upload completion photo'); return }
    if (!workerLocation) { toast.error('Capture your current location'); return }

    setCompleting(true)
    try {
      const fd = new FormData()
      fd.append('photo', completionPhoto)
      const res = await workerAPI.submitCompletion(selected.id, fd, workerLocation.lat, workerLocation.lng)
      dispatch({ type: 'UPDATE_COMPLAINT', payload: res.data })
      setSelected(res.data)
      setCompletionPhoto(null)
      setCompletionPreview(null)
      setWorkerLocation(null)

      if (res.data.aiVerified) {
        toast.success('Work verified by AI. Task complete!')
      } else {
        toast('Completion submitted. Awaiting officer verification.', { icon: '⚠' })
      }
    } catch (err) {
      toast.error(err.response?.data || 'Submission failed')
    } finally {
      setCompleting(false)
    }
  }

  const aiResult = selected?.aiVerificationResult ? (() => {
    try { return JSON.parse(selected.aiVerificationResult) } catch { return null }
  })() : null

  return (
    <PageLayout title="My Tasks" subtitle={`${complaints.length} tasks assigned to you`}>
      <div className="tasks-layout">
        <div className="tasks-list-col">
          <div className="filter-bar">
            {['ALL','ASSIGNED','IN_PROGRESS','COMPLETED','VERIFIED'].map(s => (
              <button key={s} className={`filter-btn ${filter === s ? 'active' : ''}`} onClick={() => setFilter(s)}>
                {s.replace('_',' ')}
              </button>
            ))}
          </div>

          {loading ? (
            <div className="loading-list">{[1,2,3].map(i => <div key={i} className="skeleton-card" />)}</div>
          ) : filtered.length === 0 ? (
            <div className="empty-state"><div className="empty-icon">📋</div><p>No tasks in this status.</p></div>
          ) : (
            <div className="tasks-list">
              {filtered.map(c => (
                <div
                  key={c.id}
                  className={`task-card ${selected?.id === c.id ? 'selected' : ''}`}
                  onClick={() => setSelected(c)}
                >
                  <div className="tc-top">
                    <div className="tc-priority-badge" style={{ color: priorityColor[c.priority], background: priorityColor[c.priority] + '18', borderColor: priorityColor[c.priority] + '40' }}>
                      {c.priority}
                    </div>
                    <div className="tc-status" style={{ color: statusColor[c.status] }}>
                      {c.status?.replace('_',' ')}
                    </div>
                  </div>
                  <div className="tc-title">{c.title}</div>
                  <div className="tc-meta">
                    <span>◎ {c.address || `${c.latitude?.toFixed(4)}, ${c.longitude?.toFixed(4)}`}</span>
                  </div>
                  {c.estimatedCompletionTime && (
                    <div className="tc-eta">ETA: {new Date(c.estimatedCompletionTime).toLocaleDateString()}</div>
                  )}
                  {c.aiVerified && <div className="tc-ai-badge">AI Verified</div>}
                </div>
              ))}
            </div>
          )}
        </div>

        {selected && (
          <div className="task-detail-col">
            <div className="td-header">
              <h2>{selected.title}</h2>
              <button className="td-close" onClick={() => setSelected(null)}>✕</button>
            </div>

            <p className="td-desc">{selected.description}</p>

            <div className="td-info-grid">
              <div className="td-info-item"><span>Category</span><span>{selected.category?.replace('_',' ')}</span></div>
              <div className="td-info-item"><span>Priority</span><span style={{ color: priorityColor[selected.priority] }}>{selected.priority}</span></div>
              <div className="td-info-item"><span>Reported by</span><span>{selected.citizen?.fullName}</span></div>
              <div className="td-info-item"><span>Location</span><span>{selected.address || `${selected.latitude?.toFixed(5)}, ${selected.longitude?.toFixed(5)}`}</span></div>
              {selected.estimatedCompletionTime && (
                <div className="td-info-item"><span>ETA</span><span>{new Date(selected.estimatedCompletionTime).toLocaleString()}</span></div>
              )}
            </div>

            {selected.latitude && selected.longitude && (
              <a
                className="navigate-btn"
                href={`https://www.google.com/maps/dir/?api=1&destination=${selected.latitude},${selected.longitude}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                ◎ Navigate to Location
              </a>
            )}

            {selected.beforePhotoUrl && (
              <div className="photo-section">
                <div className="photo-section-label">Before Photo (by citizen)</div>
                <img src={selected.beforePhotoUrl} alt="Before" className="td-photo" />
              </div>
            )}

            {selected.afterPhotoUrl && (
              <div className="photo-section">
                <div className="photo-section-label">After Photo (your upload)</div>
                <img src={selected.afterPhotoUrl} alt="After" className="td-photo" />
              </div>
            )}

            {aiResult && (
              <div className={`ai-result-card ${aiResult.verified ? 'ai-pass' : 'ai-fail'}`}>
                <div className="ai-result-title">AI Verification Result</div>
                <div className="ai-checks">
                  <div className={`ai-check ${aiResult.workCompleted ? 'pass' : 'fail'}`}>{aiResult.workCompleted ? '✓' : '✗'} Work Completed</div>
                  <div className={`ai-check ${aiResult.locationMatch ? 'pass' : 'fail'}`}>{aiResult.locationMatch ? '✓' : '✗'} Location Match</div>
                  <div className={`ai-check ${aiResult.verified ? 'pass' : 'fail'}`}>{aiResult.verified ? '✓' : '✗'} Overall: {aiResult.verified ? 'APPROVED' : 'FAILED'}</div>
                </div>
                <p className="ai-reasoning">{aiResult.reasoning}</p>
                <div className="ai-confidence-bar">
                  <div className="acb-fill" style={{ width: `${(aiResult.confidenceScore||0)*100}%` }} />
                </div>
                <div className="ai-confidence-label">{Math.round((aiResult.confidenceScore||0)*100)}% confidence</div>
              </div>
            )}

            {['ASSIGNED','IN_PROGRESS'].includes(selected.status) && (
              <div className="completion-section">
                <div className="cs-title">Submit Completion</div>

                {selected.status === 'ASSIGNED' && (
                  <button className="start-work-btn" onClick={() => handleStartWork(selected)}>
                    Start Working
                  </button>
                )}

                {selected.status === 'IN_PROGRESS' && (
                  <>
                    <div className="location-capture">
                      <button className="locate-btn" onClick={captureWorkerLocation} disabled={gettingLocation}>
                        {gettingLocation ? 'Getting location...' : '◎ Capture Current Location'}
                      </button>
                      {workerLocation && (
                        <div className="coords-tag">✓ Location captured: {workerLocation.lat.toFixed(5)}, {workerLocation.lng.toFixed(5)}</div>
                      )}
                    </div>

                    <div className="photo-upload" onClick={() => fileRef.current.click()}>
                      {completionPreview ? (
                        <img src={completionPreview} alt="completion" className="photo-preview-img" />
                      ) : (
                        <div className="photo-placeholder">
                          <span>📷</span>
                          <span>Upload After Photo</span>
                        </div>
                      )}
                    </div>
                    <input ref={fileRef} type="file" accept="image/*" onChange={handlePhotoChange} hidden />

                    <button className="submit-completion-btn" onClick={handleSubmitCompletion} disabled={completing || !completionPhoto || !workerLocation}>
                      {completing ? 'Submitting & Running AI Verification...' : 'Submit Completion'}
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </PageLayout>
  )
}
