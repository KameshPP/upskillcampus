import React, { createContext, useContext, useReducer, useCallback } from 'react'

const StoreContext = createContext(null)

const initialState = {
  user: null,
  token: localStorage.getItem('civicfix_token') || null,
  complaints: [],
  nearbyComplaints: [],
  workers: [],
  loading: false,
  error: null,
}

function reducer(state, action) {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, user: action.payload }
    case 'SET_TOKEN':
      return { ...state, token: action.payload }
    case 'SET_COMPLAINTS':
      return { ...state, complaints: action.payload }
    case 'SET_NEARBY_COMPLAINTS':
      return { ...state, nearbyComplaints: action.payload }
    case 'ADD_COMPLAINT':
      return { ...state, complaints: [action.payload, ...state.complaints] }
    case 'UPDATE_COMPLAINT':
      return {
        ...state,
        complaints: state.complaints.map(c =>
          c.id === action.payload.id ? action.payload : c
        ),
        nearbyComplaints: state.nearbyComplaints.map(c =>
          c.id === action.payload.id ? action.payload : c
        ),
      }
    case 'SET_WORKERS':
      return { ...state, workers: action.payload }
    case 'SET_LOADING':
      return { ...state, loading: action.payload }
    case 'SET_ERROR':
      return { ...state, error: action.payload }
    case 'LOGOUT':
      return { ...initialState, token: null }
    default:
      return state
  }
}

export function StoreProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState)

  const login = useCallback((user, token) => {
    localStorage.setItem('civicfix_token', token)
    dispatch({ type: 'SET_USER', payload: user })
    dispatch({ type: 'SET_TOKEN', payload: token })
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem('civicfix_token')
    dispatch({ type: 'LOGOUT' })
  }, [])

  const value = {
    ...state,
    dispatch,
    login,
    logout,
  }

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
}

export function useStore() {
  const ctx = useContext(StoreContext)
  if (!ctx) throw new Error('useStore must be used within StoreProvider')
  return ctx
}
