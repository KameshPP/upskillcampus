import React from 'react'
import './ComplaintCard.css'

const priorityConfig = {
  URGENT: { color: '#ff3d57', label: 'Urgent' },
  HIGH:   { color: '#ffab00', label: 'High' },
  MEDIUM: { color: '#00d4ff', label: 'Medium' },
  LOW:    { color: '#00e676', label: 'Low' },
}

const statusConfig = {
  PENDING:     { color: '#ffab00', label: 'Pending' },
  ASSIGNED:    { color: '#00d4ff', label: 'Assigned' },
  IN_PROGRESS: { color: '#7c4dff', label: 'In Progress' },
  COMPLETED:   { color: '#00e676', label: 'Completed' },
  VERIFIED:    { color: '#00e676', label: 'Verified' },
  REJECTED:    { color: '#ff3d57', label: 'Rejected' },
  REOPENED:    { color: '#ff3d57', label: 'Reopened' },
}

const categoryIcons = {
  ROAD_DAMAGE: '🛣',
  WATER_SUPPLY: '💧',
  ELECTRICITY: '⚡',
  GARBAGE: '♻',
  SEWAGE: '🚰',
  STREET_LIGHT: '💡',
  TREE: '🌳',
  OTHER: '⚙',
}

export default function ComplaintCard({ complaint, onClick, actions, currentUserId }) {
  const priority = priorityConfig[complaint.priority] || priorityConfig.MEDIUM
  const status = statusConfig[complaint.status] || statusConfig.PENDING
  const catIcon = categoryIcons[complaint.category] || '⚙'
  const hasUpvoted = complaint.upvoterIds?.includes(currentUserId)

  return (
    <div className="complaint-card" onClick={onClick} style={{ cursor: onClick ? 'pointer' : 'default' }}>
      <div className="card-header">
        <div className="card-category">
          <span className="cat-icon">{catIcon}</span>
          <span className="cat-label">{complaint.category?.replace('_', ' ')}</span>
        </div>
        <div className="card-badges">
          <span className="badge" style={{ color: priority.color, borderColor: priority.color + '40', background: priority.color + '15' }}>
            {priority.label}
          </span>
          <span className="badge" style={{ color: status.color, borderColor: status.color + '40', background: status.color + '15' }}>
            {status.label}
          </span>
        </div>
      </div>

      <h3 className="card-title">{complaint.title}</h3>
      <p className="card-desc">{complaint.description}</p>

      <div className="card-meta">
        <span className="meta-item">
          <span>◎</span> {complaint.address || `${complaint.latitude?.toFixed(4)}, ${complaint.longitude?.toFixed(4)}`}
        </span>
        <span className="meta-item">
          <span>◷</span> {complaint.createdAt ? new Date(complaint.createdAt).toLocaleDateString() : '—'}
        </span>
      </div>

      {complaint.assignedWorker && (
        <div className="card-worker">
          Worker: <strong>{complaint.assignedWorker.fullName}</strong>
          {complaint.estimatedCompletionTime && (
            <span> · ETA {new Date(complaint.estimatedCompletionTime).toLocaleDateString()}</span>
          )}
        </div>
      )}

      <div className="card-footer">
        <div className="upvote-row">
          <span className={`upvote-count ${hasUpvoted ? 'upvoted' : ''}`}>
            ▲ {complaint.upvotes || 0}
          </span>
          <span className="card-reporter">by {complaint.citizen?.fullName}</span>
        </div>
        {actions && <div className="card-actions" onClick={(e) => e.stopPropagation()}>{actions}</div>}
      </div>

      {complaint.aiVerified && (
        <div className="ai-badge">AI Verified</div>
      )}
    </div>
  )
}
