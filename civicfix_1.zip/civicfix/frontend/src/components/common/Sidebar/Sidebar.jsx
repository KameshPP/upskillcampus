import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { useStore } from '../../../context/StoreContext'
import './Sidebar.css'

const roleNav = {
  CITIZEN: [
    { label: 'Dashboard', icon: '⬡', path: '/citizen/dashboard' },
    { label: 'My Complaints', icon: '◈', path: '/citizen/complaints' },
    { label: 'Nearby Map', icon: '◎', path: '/citizen/map' },
  ],
  OFFICER: [
    { label: 'Dashboard', icon: '⬡', path: '/officer/dashboard' },
    { label: 'All Complaints', icon: '◈', path: '/officer/complaints' },
    { label: 'Map View', icon: '◎', path: '/officer/map' },
    { label: 'Users', icon: '◷', path: '/officer/users' },
  ],
  WORKER: [
    { label: 'Dashboard', icon: '⬡', path: '/worker/dashboard' },
    { label: 'My Tasks', icon: '◈', path: '/worker/tasks' },
  ],
}

export default function Sidebar() {
  const { user, logout } = useStore()
  const navigate = useNavigate()

  const navItems = roleNav[user?.role] || []

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const roleLabel = {
    CITIZEN: 'Citizen',
    OFFICER: 'Officer',
    WORKER: 'Field Worker',
  }

  const roleColor = {
    CITIZEN: '#00d4ff',
    OFFICER: '#7c4dff',
    WORKER: '#00e676',
  }

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div className="sidebar-logo">
          <span className="logo-mark">C</span>
          <span className="logo-text">CivicFix</span>
        </div>
        <div className="sidebar-tagline">Urban Issue Management</div>
      </div>

      <div className="sidebar-user">
        <div className="user-avatar" style={{ borderColor: roleColor[user?.role] }}>
          {user?.fullName?.charAt(0).toUpperCase()}
        </div>
        <div className="user-info">
          <div className="user-name">{user?.fullName}</div>
          <div className="user-role" style={{ color: roleColor[user?.role] }}>
            {roleLabel[user?.role]}
          </div>
        </div>
      </div>

      <nav className="sidebar-nav">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <span className="nav-icon">{item.icon}</span>
            <span className="nav-label">{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <button className="sidebar-logout" onClick={handleLogout}>
        <span>⏻</span>
        <span>Sign Out</span>
      </button>
    </aside>
  )
}
