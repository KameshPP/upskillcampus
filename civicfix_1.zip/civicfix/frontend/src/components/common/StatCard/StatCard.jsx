import React from 'react'
import './StatCard.css'

export default function StatCard({ label, value, icon, color = 'var(--accent-primary)', trend }) {
  return (
    <div className="stat-card" style={{ '--card-accent': color }}>
      <div className="stat-top">
        <span className="stat-label">{label}</span>
        <span className="stat-icon">{icon}</span>
      </div>
      <div className="stat-value">{value}</div>
      {trend && <div className="stat-trend">{trend}</div>}
      <div className="stat-bar" />
    </div>
  )
}
