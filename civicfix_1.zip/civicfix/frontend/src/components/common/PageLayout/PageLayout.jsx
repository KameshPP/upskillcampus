import React from 'react'
import Sidebar from '../Sidebar/Sidebar'
import './PageLayout.css'

export default function PageLayout({ children, title, subtitle, actions }) {
  return (
    <div className="layout">
      <Sidebar />
      <main className="layout-main">
        <div className="layout-header">
          <div className="header-text">
            <h1 className="header-title">{title}</h1>
            {subtitle && <p className="header-subtitle">{subtitle}</p>}
          </div>
          {actions && <div className="header-actions">{actions}</div>}
        </div>
        <div className="layout-content">{children}</div>
      </main>
    </div>
  )
}
