import React from 'react'
import './Button.css'

export default function Button({ children, variant = 'primary', size = 'md', loading, disabled, onClick, type = 'button', fullWidth }) {
  return (
    <button
      type={type}
      className={`btn btn-${variant} btn-${size} ${fullWidth ? 'btn-full' : ''} ${loading ? 'btn-loading' : ''}`}
      disabled={disabled || loading}
      onClick={onClick}
    >
      {loading ? <span className="btn-spinner" /> : children}
    </button>
  )
}
